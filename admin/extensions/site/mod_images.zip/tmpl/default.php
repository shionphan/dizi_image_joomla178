<?php
/**
 * @module		com_di
 * @script		default.php
 * @author-name Tomas Kartasovas
 * @copyright	Copyright (C) 2013 dizi.lt
 */

// No direct access to this file
defined( '_JEXEC' ) or die();

$height = (int) $params->get( 'row_height', 120 );
$margin = (int) $params->get( 'margin', 3 );

?>
<?php if( $list ) : ?>
	<div class="gallery flex" id="dGallery">
		<?php if( $module->showtitle ) : ?>
			<h3><?php echo $module->title; ?></h3>
		<?php endif; ?>
		
		<div class="pictures" id="diPictures">
			<?php foreach( $list as $key => $item ) : ?>
				<?php
					if( $params->get( 'fluid' ) )
					{
						$d = $height / $item->info->thumb[ 1 ];
						$item->info->thumb[ 0 ] = $item->info->thumb[ 0 ] * $d;
						$item->info->thumb[ 1 ] = $height;
					}
				?>
				<a
					class="item <?php echo !$key ? 'item-first' : ''; ?> fancy"
					rel="images"
					title="<?php echo $item->title; ?>"
					href="<?php echo $item->src->zoomed; ?>"
					
					<?php if( !empty( $item->info->thumb[ 0 ] )
							&& !empty( $item->info->thumb[ 1 ] )
					) : ?>
						style="width: <?php echo $item->info->thumb[ 0 ]; ?>px; flex-grow: <?php echo $item->info->thumb[ 0 ] * $height / $item->info->thumb[ 1 ] ?>"
					<?php endif; ?>
				>
					<?php if( !empty( $item->info->thumb[ 0 ] )
							&& !empty( $item->info->thumb[ 1 ] )
					) : ?>
						<i style="padding-bottom: <?php echo $height / $item->info->thumb[ 0 ] * 100; ?>%"></i>
					<?php endif; ?>
					<img
						alt="<?php echo $item->title; ?>"
						height="<?php echo !empty( $item->info->thumb[ 1 ] ) ? (int) $item->info->thumb[ 1 ] : ''; ?>"
						src="<?php echo $item->src->thumb; ?>"
						title="<?php echo $item->title; ?>"
						width="<?php echo !empty( $item->info->thumb[ 0 ] ) ? (int) $item->info->thumb[ 0 ] : ''; ?>"
					/>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
	
	<style>
		.gallery .pictures:before,
		.gallery .pictures:after { content: ""; display: table; }
		.gallery .pictures:after { clear: both; }
		.gallery .pictures .item { display: inline-block; float: left; margin-bottom: <?php echo $margin; ?>px; }
		.gallery .pictures .item i { display: none; }
		.gallery .pictures .item img { height: 100%; max-height: 100%; max-width: 100%; vertical-align: bottom; }
		
		.gallery.flex .pictures { display: flex; flex-wrap: wrap; }
		.gallery.flex .pictures::after { content: ''; flex-grow: 1e4; min-width: 20%; }
		.gallery.flex .pictures .item { margin-bottom: 3px; margin-right: 3px; position: relative; }
		.gallery.flex .pictures .item i { display: block; }
		.gallery.flex .pictures .item img { position: absolute; top: 0; width: 100%; }
		
		<?php if( !$params->get( 'fluid' ) ) : ?>
			.gallery .pictures .item { margin-right: <?php echo $margin; ?>px; }
		<?php endif; ?>
	</style>
	
	<?php if( $params->get( 'fluid' ) ) : ?>
		<script>
			var di_settings = {
				margin: <?php echo $margin; ?>
			};
			
			var d = document.documentElement.style;
			var el_d_gallery = document.getElementById( 'dGallery' );
			var ua = window.navigator.userAgent;
			var msie = ua.indexOf( 'MSIE ' );
			
			// test
			el_d_gallery.className.replace( 'flex', '' );
			
			if( !( ( 'flexWrap' in d )
					|| ( 'WebkitFlexWrap' in d )
					|| ( 'msFlexWrap' in d )
				) || ( msie !== -1
					|| !!navigator.userAgent.match( /Trident.*rv\:11\./ )
				)
			){
				el_d_gallery.className = el_d_gallery.className.replace( 'flex', '' );
				
				var s = document.createElement( 'script' );
                    s.type = 'text/javascript';
                    s.async = true;
                    s.defer = true;
                    s.src = '<?php echo JUri::root(); ?>media/com_di/js/fallback.flex.js';

                document.getElementsByTagName( 'body' )[ 0 ].appendChild( s );
			}
		</script>
	<?php endif; ?>
	
	<?php if( $params->get( 'load_fancybox' ) ) : ?>
		<link rel="stylesheet" href="<?php echo JUri::root(); ?>media/com_di/js/jquery.fancybox-1.3.4/fancybox/jquery.fancybox-1.3.4.css" type="text/css" />
		<script src="<?php echo JUri::root(); ?>media/com_di/js/jquery.fancybox-1.3.4/fancybox/jquery.fancybox-1.3.4.pack.js" type="text/javascript"></script>
		<script>
			if( typeof jQuery == 'function' )
				jQuery( function(){
					if( typeof jQuery.fancybox == 'function'
						|| typeof $.fancybox == 'function'
					)
						jQuery( '.fancy' ).fancybox( {
							transitionIn: 'elastic',
							transitionOut: 'elastic',
							titlePosition: 'inside'
						} );
				} );
		</script>
	<?php endif; ?>
<?php endif; ?>
